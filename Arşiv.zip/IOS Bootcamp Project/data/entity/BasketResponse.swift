//
//  BasketResponse.swift
//  IOS Bootcamp Project
//
//  Created by Abdulkadir Aktar on 2.06.2024.
//

import Foundation

class BasketResponse : Codable {
    var sepet_yemekler: [BasketFood]?
    var success: Int?
   
}
