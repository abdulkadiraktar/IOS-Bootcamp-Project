//
//  FoodResponse.swift
//  IOS Bootcamp Project
//
//  Created by Abdulkadir Aktar on 2.06.2024.
//

import Foundation

class FoodResponse : Codable{
    var yemekler : [Food]?
    var success : Int?
}
