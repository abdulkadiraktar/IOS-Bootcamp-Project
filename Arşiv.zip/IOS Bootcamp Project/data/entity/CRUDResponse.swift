//
//  CRUDResponse.swift
//  IOS Bootcamp Project
//
//  Created by Abdulkadir Aktar on 2.06.2024.
//

import Foundation

class CRUDResponse : Codable {
    var success : Int?
    var message : String?
}
