//
//  FoodCellCollectionViewCell.swift
//  IOS Bootcamp Project
//
//  Created by Abdulkadir Aktar on 1.06.2024.
//

import UIKit

class FoodCellCollectionViewCell: UICollectionViewCell {
    
}
